// Temel park yeri sınıfı (Abstract)
public abstract class ParkingSpot {
    private String spotId;
    private boolean isOccupied;
    private Vehicle parkedVehicle;

    public ParkingSpot(String spotId) {
        this.spotId = spotId;
        this.isOccupied = false;
        this.parkedVehicle = null;
    }

    // Abstract methods
    public abstract String getSpotType();
    public abstract double getPriceMultiplier();
    public abstract boolean canFitVehicle(Vehicle vehicle);

    // Park etme metodu
    public void parkVehicle(Vehicle vehicle) throws Exception {
        if (isOccupied) {
            throw new Exception("Spot is already occupied!");
        }
        if (!canFitVehicle(vehicle)) {
            throw new Exception("Vehicle cannot fit in this spot!");
        }
        this.parkedVehicle = vehicle;
        this.isOccupied = true;
    }

    // Aracı çıkarma metodu
    public Vehicle removeVehicle() throws Exception {
        if (!isOccupied) {
            throw new Exception("No vehicle parked in this spot!");
        }
        Vehicle vehicle = this.parkedVehicle;
        this.parkedVehicle = null;
        this.isOccupied = false;
        return vehicle;
    }

    // Getters
    public String getSpotId() {
        return spotId;
    }

    public boolean isOccupied() {
        return isOccupied;
    }

    public Vehicle getParkedVehicle() {
        return parkedVehicle;
    }

    @Override
    public String toString() {
        return getSpotType() + " - " + spotId + " - " +
                (isOccupied ? "OCCUPIED" : "AVAILABLE");
    }
}

// RegularSpot sınıfı
class RegularSpot extends ParkingSpot {

    public RegularSpot(String spotId) {
        super(spotId);
    }

    @Override
    public String getSpotType() {
        return "Regular Spot";
    }

    @Override
    public double getPriceMultiplier() {
        return 1.0;
    }

    @Override
    public boolean canFitVehicle(Vehicle vehicle) {
        // Truck hariç hepsini alır
        return !(vehicle instanceof Truck);
    }
}

// ElectricChargingSpot sınıfı
class ElectricChargingSpot extends ParkingSpot {
    private int chargingPower; // kW
    private boolean isCharging;

    public ElectricChargingSpot(String spotId, int chargingPower) {
        super(spotId);
        this.chargingPower = chargingPower;
        this.isCharging = false;
    }

    @Override
    public String getSpotType() {
        return "Electric Charging Spot";
    }

    @Override
    public double getPriceMultiplier() {
        return 1.5; // Şarj ücreti dahil
    }

    @Override
    public boolean canFitVehicle(Vehicle vehicle) {
        return vehicle instanceof ElectricVehicle;
    }

    @Override
    public void parkVehicle(Vehicle vehicle) throws Exception {
        super.parkVehicle(vehicle);
        if (vehicle instanceof ElectricVehicle) {
            ElectricVehicle ev = (ElectricVehicle) vehicle;
            if (ev.isNeedsCharging()) {
                this.isCharging = true;
            }
        }
    }

    public int getChargingPower() {
        return chargingPower;
    }

    public boolean isCharging() {
        return isCharging;
    }
}