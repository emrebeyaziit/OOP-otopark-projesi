import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("╔════════════════════════════════════════════════╗");
            System.out.println("║      OTOPARK YÖNETİM SİSTEMİ                  ║");
            System.out.println("║      Tek Kat - 50 Park Yeri                    ║");
            System.out.println("╚════════════════════════════════════════════════╝\n");

            // Sistem başlatma
            ParkingLot parkingLot = new ParkingLot("City Center Parking", "İstanbul");

            // Çalışanları ekle
            setupEmployees(parkingLot);

            System.out.println("\n✓ Sistem hazır!");
            System.out.println("Toplam Kapasite: " + parkingLot.getTotalCapacity() + " araç");
            System.out.println("Elektrikli Şarj Yerleri: 10 adet");
            System.out.println("Normal Park Yerleri: 40 adet\n");

            // Test senaryoları
            runBasicScenarios(parkingLot);
            runChargingScenarios(parkingLot);

            System.out.println("\n✓ Tüm senaryolar başarıyla tamamlandı!");

        } catch (Exception e) {
            System.err.println("HATA: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void setupEmployees(ParkingLot parkingLot) {
        System.out.println("\n>>> Çalışanlar ekleniyor...");

        parkingLot.addEmployee(new ParkingAttendant(
                "E001", "Ahmet Yılmaz", "05551234567",
                "ATT001", 8000, 0
        ));

        parkingLot.addEmployee(new Manager(
                "E002", "Mehmet Kaya", "05556661122",
                "MGR001", 15000, "Operations"
        ));

        System.out.println("✓ 2 çalışan eklendi");
    }

    private static void runBasicScenarios(ParkingLot parkingLot) throws ParkingException {
        System.out.println("\n╔════════════════════════════════════════╗");
        System.out.println("║       PARK SENARYOLARI                ║");
        System.out.println("╚════════════════════════════════════════╝");

        // SENARYO 1: Saatlik bilet
        System.out.println("\n>>> SENARYO 1: Saatlik Park");
        System.out.println("-".repeat(50));

        Customer customer1 = new Customer(
                "C001", "Ali Veli", "05551111111", "34ABC123"
        );

        Car car1 = new Car("34ABC123", "Siyah", "Toyota", "Corolla");

        Ticket ticket1 = parkingLot.enterVehicle(car1, customer1, "HOURLY");
        System.out.println("✓ Saatlik bilet verildi: " + ticket1.getTicketId());
        System.out.println("Park Yeri: " + ticket1.getAssignedSpot().getSpotId());

        simulateWait(2);

        System.out.println("\n>>> Araç çıkış yapıyor...");
        CashPayment payment1 = new CashPayment("P001", 40, 50);
        parkingLot.exitVehicle(ticket1.getTicketId(), payment1);

        // SENARYO 2: Günlük bilet
        System.out.println("\n\n>>> SENARYO 2: Günlük Park");
        System.out.println("-".repeat(50));

        Customer customer2 = new Customer(
                "C002", "Zeynep Ak", "05552222222", "34XYZ789"
        );

        Van van1 = new Van("34XYZ789", "Beyaz", "Mercedes", "Vito", 8);

        Ticket ticket2 = parkingLot.enterVehicle(van1, customer2, "DAILY");
        System.out.println("✓ Günlük bilet verildi: " + ticket2.getTicketId());
        System.out.println("Park Yeri: " + ticket2.getAssignedSpot().getSpotId());

        // SENARYO 3: Aylık abonelik
        System.out.println("\n\n>>> SENARYO 3: Aylık Abonelik");
        System.out.println("-".repeat(50));

        Customer customer3 = new Customer(
                "C003", "Mehmet Kara", "05553333333", "34MHM456"
        );

        Car car2 = new Car("34MHM456", "Mavi", "BMW", "320i");

        Ticket ticket3 = parkingLot.enterVehicle(car2, customer3, "MONTHLY");
        System.out.println("✓ Aylık abonelik aktif: " + ticket3.getTicketId());
        System.out.println("Park Yeri: " + ticket3.getAssignedSpot().getSpotId());
    }

    private static void runChargingScenarios(ParkingLot parkingLot) throws ParkingException {
        System.out.println("\n╔════════════════════════════════════════╗");
        System.out.println("║    ELEKTRİKLİ ARAÇ ŞARJ SENARYOLARI   ║");
        System.out.println("╚════════════════════════════════════════╝");

        // SENARYO 4: Elektrikli araç şarjı
        System.out.println("\n>>> SENARYO 4: Tesla Şarj");
        System.out.println("-".repeat(50));

        Customer customer4 = new Customer(
                "C004", "Deniz Arslan", "05554444444", "34EV111"
        );

        ElectricVehicle ev1 = new ElectricVehicle(
                "34EV111", "Beyaz", "Tesla", "Model 3", 75
        );
        ev1.setNeedsCharging(true);

        Ticket ticket4 = parkingLot.enterVehicle(ev1, customer4, "MONTHLY");
        System.out.println("✓ Elektrikli araç park edildi ve şarj başladı");
        System.out.println("Park Yeri: " + ticket4.getAssignedSpot().getSpotId());

        // SENARYO 5: Şarj istasyonlarını listele
        System.out.println("\n>>> SENARYO 5: Şarj İstasyonları");
        System.out.println("-".repeat(50));
        parkingLot.getChargingManager().listAllStations();
    }

    private static void simulateWait(int hours) {
        System.out.println("... " + hours + " saat park simülasyonu ...");
    }
}