import java.util.*;
import java.time.LocalDateTime;

// Ana otopark sistemi sınıfı
public class ParkingLot {
    private String name;
    private String address;
    private List<ParkingSpot> spots;
    private List<Gate> gates;
    private Map<String, Ticket> activeTickets;
    private List<Transaction> transactionHistory;
    private List<Customer> customers;
    private List<Employee> employees;
    private double totalRevenue;

    // Servisler
    private ChargingStationManager chargingManager;

    public ParkingLot(String name, String address) {
        this.name = name;
        this.address = address;
        this.spots = new ArrayList<>();
        this.gates = new ArrayList<>();
        this.activeTickets = new HashMap<>();
        this.transactionHistory = new ArrayList<>();
        this.customers = new ArrayList<>();
        this.employees = new ArrayList<>();
        this.totalRevenue = 0.0;

        this.chargingManager = new ChargingStationManager();

        initializeSpots();
        initializeGates();
        initializeServices();
    }

    private void initializeSpots() {
        // 50 park yeri: 10 elektrikli + 40 normal
        for (int i = 0; i < 50; i++) {
            String spotId = "P" + (i + 1);

            if (i < 10) {
                // İlk 10 yer elektrikli araç şarj yeri
                spots.add(new ElectricChargingSpot(spotId, 50));
            } else {
                // Geri kalan 40 yer normal
                spots.add(new RegularSpot(spotId));
            }
        }
    }

    private void initializeGates() {
        gates.add(new Gate("G1", "ENTRY"));
        gates.add(new Gate("G2", "EXIT"));
    }

    private void initializeServices() {
        // Elektrikli araç şarj istasyonlarını kur
        List<ElectricChargingSpot> evSpots = new ArrayList<>();
        for (ParkingSpot spot : spots) {
            if (spot instanceof ElectricChargingSpot) {
                evSpots.add((ElectricChargingSpot) spot);
            }
        }
        chargingManager.initializeStations(evSpots);
    }

    // Araç girişi
    public Ticket enterVehicle(Vehicle vehicle, Customer customer, String ticketType)
            throws ParkingException {

        if (!customers.contains(customer)) {
            customers.add(customer);
        }

        ParkingSpot availableSpot = findAvailableSpot(vehicle);
        if (availableSpot == null) {
            throw new SpotNotAvailableException(vehicle.getVehicleType());
        }

        String ticketId = "T" + System.currentTimeMillis();
        Ticket ticket = createTicket(ticketId, customer, vehicle, ticketType);

        Employee attendant = findAvailableAttendant();
        EntryTransaction entry = new EntryTransaction(
                "ET" + System.currentTimeMillis(),
                ticket,
                attendant,
                availableSpot
        );

        entry.execute();

        activeTickets.put(ticket.getTicketId(), ticket);
        transactionHistory.add(entry);

        // Elektrikli araç ise şarj başlat
        if (vehicle instanceof ElectricVehicle) {
            ElectricVehicle ev = (ElectricVehicle) vehicle;
            if (ev.isNeedsCharging() && availableSpot instanceof ElectricChargingSpot) {
                System.out.println("\n🔋 Electric vehicle detected. Starting charging...");
                chargingManager.startCharging(ev, 100);
            }
        }

        return ticket;
    }

    // Araç çıkışı
    public void exitVehicle(String ticketId, Payment payment) throws ParkingException {
        Ticket ticket = activeTickets.get(ticketId);

        if (ticket == null) {
            throw new ParkingException("Ticket not found: " + ticketId);
        }

        Employee attendant = findAvailableAttendant();
        ExitTransaction exit = new ExitTransaction(
                "XT" + System.currentTimeMillis(),
                ticket,
                attendant
        );

        if (exit.getTotalFee() > 0 && payment != null) {
            exit.processPayment(payment);
            totalRevenue += exit.getTotalFee();
        }

        exit.execute();

        activeTickets.remove(ticketId);
        transactionHistory.add(exit);
    }

    // Şarj rezervasyonu oluştur
    public ChargingReservation reserveCharging(Customer customer, ElectricVehicle vehicle,
                                               LocalDateTime scheduledTime,
                                               int durationMinutes) {
        return chargingManager.createReservation(
                customer, vehicle, scheduledTime, durationMinutes, "Type2"
        );
    }

    private ParkingSpot findAvailableSpot(Vehicle vehicle) {
        for (ParkingSpot spot : spots) {
            if (!spot.isOccupied() && spot.canFitVehicle(vehicle)) {
                return spot;
            }
        }
        return null;
    }

    private Ticket createTicket(String ticketId, Customer customer,
                                Vehicle vehicle, String type) {
        switch (type.toUpperCase()) {
            case "HOURLY":
                return new HourlyTicket(ticketId, customer, vehicle);
            case "DAILY":
                return new DailyTicket(ticketId, customer, vehicle);
            case "MONTHLY":
                return new MonthlySubscription(ticketId, customer, vehicle);
            default:
                return new HourlyTicket(ticketId, customer, vehicle);
        }
    }

    private Employee findAvailableAttendant() {
        for (Employee emp : employees) {
            if (emp instanceof ParkingAttendant) {
                return emp;
            }
        }
        return employees.isEmpty() ?
                new ParkingAttendant("E001", "Default Attendant",
                        "0000000000", "ATT001", 5000, 0) :
                employees.get(0);
    }



    // Servis getter'ları
    public ChargingStationManager getChargingManager() {
        return chargingManager;
    }

    // Diğer getter'lar
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public String getName() {
        return name;
    }

    public int getTotalCapacity() {
        return 50;
    }

    public int getOccupiedSpots() {
        return activeTickets.size();
    }

    public double getTotalRevenue() {
        double chargingRevenue = chargingManager.getTotalRevenue();
        return totalRevenue + chargingRevenue;
    }

    public List<Transaction> getTransactionHistory() {
        return transactionHistory;
    }
}

// Gate sınıfı
class Gate {
    private String gateId;
    private String type;
    private boolean isOpen;

    public Gate(String gateId, String type) {
        this.gateId = gateId;
        this.type = type;
        this.isOpen = true;
    }

    public void open() {
        this.isOpen = true;
        System.out.println("Gate " + gateId + " opened.");
    }

    public void close() {
        this.isOpen = false;
        System.out.println("Gate " + gateId + " closed.");
    }

    public String getGateId() {
        return gateId;
    }

    public String getType() {
        return type;
    }

    public boolean isOpen() {
        return isOpen;
    }
}