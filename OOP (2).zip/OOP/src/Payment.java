import java.time.LocalDateTime;

// Payment interface
interface Payable {
    boolean processPayment(double amount);
    String getPaymentMethod();
}

// Abstract Payment sınıfı
public abstract class Payment implements Payable {
    private String paymentId;
    private double amount;
    private LocalDateTime paymentTime;
    private boolean isSuccessful;

    public Payment(String paymentId, double amount) {
        this.paymentId = paymentId;
        this.amount = amount;
        this.paymentTime = LocalDateTime.now();
        this.isSuccessful = false;
    }

    // Abstract method
    public abstract boolean validate();

    // Getters
    public String getPaymentId() {
        return paymentId;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDateTime getPaymentTime() {
        return paymentTime;
    }

    public boolean isSuccessful() {
        return isSuccessful;
    }

    protected void setSuccessful(boolean successful) {
        this.isSuccessful = successful;
    }

    @Override
    public String toString() {
        return "Payment ID: " + paymentId +
                ", Method: " + getPaymentMethod() +
                ", Amount: " + amount + " TL" +
                ", Status: " + (isSuccessful ? "SUCCESS" : "FAILED");
    }
}

// CashPayment sınıfı
class CashPayment extends Payment {
    private double receivedAmount;
    private double change;

    public CashPayment(String paymentId, double amount, double receivedAmount) {
        super(paymentId, amount);
        this.receivedAmount = receivedAmount;
        this.change = 0;
    }

    @Override
    public String getPaymentMethod() {
        return "Cash";
    }

    @Override
    public boolean validate() {
        return receivedAmount >= getAmount();
    }

    @Override
    public boolean processPayment(double amount) {
        if (validate()) {
            this.change = receivedAmount - amount;
            setSuccessful(true);
            System.out.println("Cash payment processed successfully.");
            System.out.println("Change: " + change + " TL");
            return true;
        } else {
            System.out.println("Insufficient cash! Need " +
                    (amount - receivedAmount) + " TL more.");
            return false;
        }
    }

    public double getReceivedAmount() {
        return receivedAmount;
    }

    public double getChange() {
        return change;
    }
}

// CreditCardPayment sınıfı
class CreditCardPayment extends Payment {
    private String cardNumber;
    private String cardHolderName;
    private String expiryDate;
    private String cvv;

    public CreditCardPayment(String paymentId, double amount,
                             String cardNumber, String cardHolderName,
                             String expiryDate, String cvv) {
        super(paymentId, amount);
        this.cardNumber = maskCardNumber(cardNumber);
        this.cardHolderName = cardHolderName;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
    }

    @Override
    public String getPaymentMethod() {
        return "Credit Card";
    }

    @Override
    public boolean validate() {
        // Basit validasyon
        if (cardNumber == null || cardNumber.length() < 16) return false;
        if (cvv == null || cvv.length() != 3) return false;
        if (expiryDate == null || expiryDate.isEmpty()) return false;
        return true;
    }

    @Override
    public boolean processPayment(double amount) {
        if (validate()) {
            // Simülasyon: %95 başarı oranı
            boolean success = Math.random() < 0.95;
            setSuccessful(success);

            if (success) {
                System.out.println("Credit card payment processed successfully.");
                System.out.println("Card: " + cardNumber);
            } else {
                System.out.println("Credit card payment failed! Please try again.");
            }
            return success;
        } else {
            System.out.println("Invalid credit card information!");
            return false;
        }
    }

    private String maskCardNumber(String cardNumber) {
        if (cardNumber.length() < 4) return cardNumber;
        return "**** **** **** " + cardNumber.substring(cardNumber.length() - 4);
    }

    public String getCardNumber() {
        return cardNumber;
    }
}