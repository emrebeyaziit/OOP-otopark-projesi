import java.time.LocalDateTime;
import java.time.Duration;

// Temel bilet sınıfı (Abstract)
public abstract class Ticket {
    private String ticketId;
    private LocalDateTime issueTime;
    private Customer customer;
    private Vehicle vehicle;
    private ParkingSpot assignedSpot;

    public Ticket(String ticketId, Customer customer, Vehicle vehicle) {
        this.ticketId = ticketId;
        this.customer = customer;
        this.vehicle = vehicle;
        this.issueTime = LocalDateTime.now();
    }

    // Abstract methods
    public abstract String getTicketType();
    public abstract double calculateFee(Duration parkingDuration);
    public abstract boolean isValid();

    // Getters and Setters
    public String getTicketId() {
        return ticketId;
    }

    public LocalDateTime getIssueTime() {
        return issueTime;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public ParkingSpot getAssignedSpot() {
        return assignedSpot;
    }

    public void setAssignedSpot(ParkingSpot spot) {
        this.assignedSpot = spot;
    }

    @Override
    public String toString() {
        return "Ticket ID: " + ticketId +
                ", Type: " + getTicketType() +
                ", Issue Time: " + issueTime;
    }
}

// HourlyTicket sınıfı
class HourlyTicket extends Ticket {
    private static final double BASE_RATE_PER_HOUR = 20.0;

    public HourlyTicket(String ticketId, Customer customer, Vehicle vehicle) {
        super(ticketId, customer, vehicle);
    }

    @Override
    public String getTicketType() {
        return "Saatlik Bilet";
    }

    @Override
    public double calculateFee(Duration parkingDuration) {
        long hours = parkingDuration.toHours();
        if (hours == 0) hours = 1; // Minimum 1 saat

        double baseFee = hours * BASE_RATE_PER_HOUR;
        double vehicleMultiplier = getVehicle().getSizeMultiplier();
        double spotMultiplier = getAssignedSpot() != null ?
                getAssignedSpot().getPriceMultiplier() : 1.0;

        return baseFee * vehicleMultiplier * spotMultiplier;
    }

    @Override
    public boolean isValid() {
        return true; // Her zaman geçerli
    }
}

// DailyTicket sınıfı
class DailyTicket extends Ticket {
    private static final double DAILY_RATE = 150.0;
    private LocalDateTime expiryTime;

    public DailyTicket(String ticketId, Customer customer, Vehicle vehicle) {
        super(ticketId, customer, vehicle);
        this.expiryTime = getIssueTime().plusDays(1);
    }

    @Override
    public String getTicketType() {
        return "Günlük Bilet";
    }

    @Override
    public double calculateFee(Duration parkingDuration) {
        long days = parkingDuration.toDays();
        if (days == 0) days = 1; // Minimum 1 gün

        double baseFee = days * DAILY_RATE;
        double vehicleMultiplier = getVehicle().getSizeMultiplier();
        double spotMultiplier = getAssignedSpot() != null ?
                getAssignedSpot().getPriceMultiplier() : 1.0;

        return baseFee * vehicleMultiplier * spotMultiplier;
    }

    @Override
    public boolean isValid() {
        return LocalDateTime.now().isBefore(expiryTime);
    }

    public LocalDateTime getExpiryTime() {
        return expiryTime;
    }
}

// MonthlySubscription sınıfı
class MonthlySubscription extends Ticket {
    private static final double MONTHLY_RATE = 3000.0;
    private LocalDateTime expiryTime;
    private int remainingEntries;

    public MonthlySubscription(String ticketId, Customer customer, Vehicle vehicle) {
        super(ticketId, customer, vehicle);
        this.expiryTime = getIssueTime().plusMonths(1);
        this.remainingEntries = -1; // Sınırsız giriş
    }

    @Override
    public String getTicketType() {
        return "Aylık Abonelik";
    }

    @Override
    public double calculateFee(Duration parkingDuration) {
        // Abonelik ücreti önceden ödenmiş
        return 0.0;
    }

    @Override
    public boolean isValid() {
        return LocalDateTime.now().isBefore(expiryTime);
    }

    public double getSubscriptionFee() {
        return MONTHLY_RATE;
    }

    public LocalDateTime getExpiryTime() {
        return expiryTime;
    }
}