import java.util.*;
import java.time.LocalDateTime;

public class MainApp {
    private static Scanner scanner = new Scanner(System.in);
    private static ParkingLot parkingLot;
    private static Map<String, Ticket> activeTickets = new HashMap<>();

    public static void main(String[] args) {
        initializeSystem();
        showWelcomeScreen();

        while (true) {
            try {
                showMainMenu();
                int choice = getIntInput("Seçiminiz: ");

                if (choice == 0) {
                    exitSystem();
                    break;
                }

                handleMainMenuChoice(choice);

            } catch (Exception e) {
                System.out.println("\n❌ Hata: " + e.getMessage());
                pressEnterToContinue();
            }
        }
    }

    private static void initializeSystem() {
        System.out.println("Sistem başlatılıyor...");
        parkingLot = new ParkingLot("City Center Parking", "İstanbul");

        parkingLot.addEmployee(new ParkingAttendant(
                "E001", "Ahmet Yılmaz", "05551234567",
                "ATT001", 8000, 0
        ));
        parkingLot.addEmployee(new Manager(
                "E002", "Mehmet Kaya", "05556661122",
                "MGR001", 15000, "Operations"
        ));

        System.out.println("✓ Sistem hazır!\n");
    }

    private static void showWelcomeScreen() {
        clearScreen();
        System.out.println("╔════════════════════════════════════════════════════╗");
        System.out.println("║                                                    ║");
        System.out.println("║        OTOPARK YÖNETİM SİSTEMİ                     ║");
        System.out.println("║                                                    ║");
        System.out.println("║    🚗 50 Park Yeri                                 ║");
        System.out.println("║    ⚡ 10 Elektrikli Araç Şarj İstasyonu             ║");
        System.out.println("║                                                    ║");
        System.out.println("╚════════════════════════════════════════════════════╝");

        System.out.println("\n  🎯 SİSTEM HAZIR!");
        System.out.println("  ──────────────────────────────────────────────");
        System.out.println("  📊 Toplam Kapasite: 50 araç");
        System.out.println("  🟢 Tüm park yerleri müsait");
        System.out.println("  ──────────────────────────────────────────────");

        System.out.println("\n  Hoş Geldiniz! Devam etmek için ENTER'a basın...");
        scanner.nextLine();
    }

    private static void showMainMenu() {
        clearScreen();
        System.out.println("╔════════════════════════════════════════════════════╗");
        System.out.println("║               ANA MENÜ                             ║");
        System.out.println("╚════════════════════════════════════════════════════╝");
        System.out.println();

        showLiveCapacity();

        System.out.println("  ──────────────────────────────────────────────────");
        System.out.println();
        System.out.println("  1️⃣  Araç Giriş İşlemi");
        System.out.println("  2️⃣  Araç Çıkış İşlemi");
        System.out.println("  3️⃣  Aktif Biletleri Görüntüle");
        System.out.println();
        System.out.println("  4️⃣  Elektrikli Araç Şarj İstasyonları");
        System.out.println();
        System.out.println("  0️⃣  Çıkış");
        System.out.println();
        System.out.println("  ──────────────────────────────────────────────────");
        System.out.println();
    }

    private static void handleMainMenuChoice(int choice) throws ParkingException {
        switch (choice) {
            case 1:
                vehicleEntryProcess();
                break;
            case 2:
                vehicleExitProcess();
                break;
            case 3:
                viewActiveTickets();
                break;
            case 4:
                evChargingMenu();
                break;
            default:
                System.out.println("\n❌ Geçersiz seçim!");
                pressEnterToContinue();
        }
    }

    private static void vehicleEntryProcess() throws ParkingException {
        clearScreen();
        System.out.println("╔════════════════════════════════════════════════════╗");
        System.out.println("║          ARAÇ GİRİŞ İŞLEMİ                         ║");
        System.out.println("╚════════════════════════════════════════════════════╝\n");

        System.out.println("📝 MÜŞTERİ BİLGİLERİ");
        String customerId = "C" + System.currentTimeMillis();
        String name = getStringInput("Ad Soyad: ");
        String phone = getStringInput("Telefon (05XXXXXXXXX): ");
        String licensePlate = getStringInput("Araç Plakası (34ABC123): ").toUpperCase();

        Customer customer = new Customer(customerId, name, phone, licensePlate);

        System.out.println("\n🚗 ARAÇ TİPİ SEÇİMİ");
        System.out.println("1. Otomobil");
        System.out.println("2. Motosiklet");
        System.out.println("3. Kamyonet");
        System.out.println("4. Elektrikli Araç");

        int vehicleChoice = getIntInput("Seçim: ");
        Vehicle vehicle = createVehicle(vehicleChoice, licensePlate);

        if (vehicle == null) {
            System.out.println("\n❌ Geçersiz araç tipi!");
            pressEnterToContinue();
            return;
        }

        System.out.println("\n🎫 BİLET TİPİ SEÇİMİ");
        System.out.println("1. Saatlik (20 TL/saat)");
        System.out.println("2. Günlük (150 TL/gün)");
        System.out.println("3. Aylık Abonelik (3000 TL/ay)");

        int ticketChoice = getIntInput("Seçim: ");
        String ticketType = getTicketType(ticketChoice);

        Ticket ticket = parkingLot.enterVehicle(vehicle, customer, ticketType);

        activeTickets.put(ticket.getTicketId(), ticket);

        System.out.println("\n✅ ARAÇ BAŞARIYLA PARK EDİLDİ!");
        System.out.println("────────────────────────────────");
        System.out.println("Müşteri: " + customer.getName());
        System.out.println("Araç: " + vehicle.getLicensePlate());
        System.out.println("Park Yeri: " + ticket.getAssignedSpot().getSpotId());
        System.out.println("────────────────────────────────");

        System.out.println("\n📊 KAPASİTE:");
        int newOccupied = parkingLot.getOccupiedSpots();
        int newAvailable = parkingLot.getTotalCapacity() - newOccupied;
        System.out.println("Dolu: " + newOccupied + " | Boş: " + newAvailable);

        pressEnterToContinue();
    }

    private static void vehicleExitProcess() throws ParkingException {
        clearScreen();
        System.out.println("╔════════════════════════════════════════════════════╗");
        System.out.println("║          ARAÇ ÇIKIŞ İŞLEMİ                         ║");
        System.out.println("╚════════════════════════════════════════════════════╝\n");

        if (activeTickets.isEmpty()) {
            System.out.println("⚠️  Aktif bilet bulunamadı!");
            pressEnterToContinue();
            return;
        }

        System.out.println("📋 AKTİF BİLETLER:\n");
        int index = 1;
        List<String> ticketIds = new ArrayList<>(activeTickets.keySet());

        for (String ticketId : ticketIds) {
            Ticket ticket = activeTickets.get(ticketId);
            System.out.println(index + ". Araç: " + ticket.getVehicle().getLicensePlate());
            System.out.println("   Müşteri: " + ticket.getCustomer().getName());
            System.out.println();
            index++;
        }

        int choice = getIntInput("Çıkış yapacak bileti seçin (1-" + ticketIds.size() + "): ");

        if (choice < 1 || choice > ticketIds.size()) {
            System.out.println("\n❌ Geçersiz seçim!");
            pressEnterToContinue();
            return;
        }

        String selectedTicketId = ticketIds.get(choice - 1);

        double fee = 40.0; // Örnek ücret

        System.out.println("\n💰 ÖDEME BİLGİLERİ");
        System.out.println("Toplam Ücret: " + fee + " TL");
        System.out.println("\nÖdeme Yöntemi Seçin:");
        System.out.println("1. Nakit");
        System.out.println("2. Kredi Kartı");

        int paymentChoice = getIntInput("Seçim: ");
        Payment payment = createPayment(paymentChoice, fee);

        if (payment == null) {
            System.out.println("\n❌ Geçersiz ödeme yöntemi!");
            pressEnterToContinue();
            return;
        }

        parkingLot.exitVehicle(selectedTicketId, payment);
        activeTickets.remove(selectedTicketId);

        System.out.println("\n✅ ÇIKIŞ İŞLEMİ TAMAMLANDI!");
        System.out.println("İyi yolculuklar dileriz!");

        System.out.println("\n📊 KAPASİTE:");
        int newOccupied = parkingLot.getOccupiedSpots();
        int newAvailable = parkingLot.getTotalCapacity() - newOccupied;
        System.out.println("Dolu: " + newOccupied + " | Boş: " + newAvailable);

        pressEnterToContinue();
    }

    private static void viewActiveTickets() {
        clearScreen();
        System.out.println("╔════════════════════════════════════════════════════╗");
        System.out.println("║          AKTİF BİLETLER                            ║");
        System.out.println("╚════════════════════════════════════════════════════╝\n");

        if (activeTickets.isEmpty()) {
            System.out.println("⚠️  Aktif bilet bulunamadı!");
        } else {
            for (Map.Entry<String, Ticket> entry : activeTickets.entrySet()) {
                Ticket ticket = entry.getValue();
                System.out.println("────────────────────────────────");
                System.out.println("Müşteri: " + ticket.getCustomer().getName());
                System.out.println("Araç: " + ticket.getVehicle().getLicensePlate());
                System.out.println("Park Yeri: " + ticket.getAssignedSpot().getSpotId());
                System.out.println();
            }
        }

        pressEnterToContinue();
    }

    private static void evChargingMenu() {
        clearScreen();
        System.out.println("╔════════════════════════════════════════════════════╗");
        System.out.println("║          ELEKTRİKLİ ARAÇ ŞARJ İSTASYONLARI         ║");
        System.out.println("╚════════════════════════════════════════════════════╝\n");

        parkingLot.getChargingManager().listAllStations();
        pressEnterToContinue();
    }



    private static Vehicle createVehicle(int choice, String licensePlate) {
        String color = getStringInput("Renk: ");
        String brand = getStringInput("Marka: ");
        String model = getStringInput("Model: ");

        switch (choice) {
            case 1:
                return new Car(licensePlate, color, brand, model);
            case 2:
                int engineCapacity = getIntInput("Motor hacmi (cc): ");
                return new Motorcycle(licensePlate, color, brand, model, engineCapacity);
            case 3:
                int capacity = getIntInput("Yük kapasitesi: ");
                return new Van(licensePlate, color, brand, model, capacity);
            case 4:
                int battery = getIntInput("Batarya kapasitesi (kWh): ");
                ElectricVehicle ev = new ElectricVehicle(licensePlate, color, brand, model, battery);
                String needsCharge = getStringInput("Şarj gerekiyor mu? (E/H): ");
                ev.setNeedsCharging(needsCharge.equalsIgnoreCase("E"));
                return ev;
            default:
                return null;
        }
    }

    private static String getTicketType(int choice) {
        switch (choice) {
            case 1: return "HOURLY";
            case 2: return "DAILY";
            case 3: return "MONTHLY";
            default: return "HOURLY";
        }
    }

    private static Payment createPayment(int choice, double amount) {
        String paymentId = "PAY" + System.currentTimeMillis();

        switch (choice) {
            case 1:
                double cash = getDoubleInput("Verilen nakit: ");
                return new CashPayment(paymentId, amount, cash);
            case 2:
                String cardNumber = getStringInput("Kart numarası: ");
                String cardHolder = getStringInput("Kart sahibi: ");
                String expiry = getStringInput("Son kullanma (MM/YY): ");
                String cvv = getStringInput("CVV: ");
                return new CreditCardPayment(paymentId, amount, cardNumber, cardHolder, expiry, cvv);
            default:
                return null;
        }
    }

    private static void exitSystem() {
        clearScreen();
        System.out.println("\n╔════════════════════════════════════════════════════╗");
        System.out.println("  ║                                                    ║");
        System.out.println("  ║     Otopark Yönetim Sisteminden Çıkılıyor...       ║");
        System.out.println("  ║                                                    ║");
        System.out.println("  ║            Güle güle! 👋                           ║");
        System.out.println("  ║                                                    ║");
        System.out.println("  ╚════════════════════════════════════════════════════╝\n");

        System.out.println("📊 GÜNLÜK ÖZET:");
        System.out.println("Toplam İşlem: " + parkingLot.getTransactionHistory().size());
        System.out.println();
    }

    private static void showLiveCapacity() {
        int totalCapacity = parkingLot.getTotalCapacity();
        int occupied = parkingLot.getOccupiedSpots();
        int available = totalCapacity - occupied;

        System.out.println("  ┌────────────────────────────────────────────────┐");
        System.out.println("  │         🚗 KAPASİTE BİLGİSİ                    │");
        System.out.println("  ├────────────────────────────────────────────────┤");
        System.out.println("  │                                                │");
        System.out.println("  │  📊 Toplam Kapasite : 50 araç                  │");
        System.out.println("  │  🚗 Dolu            : " + String.format("%-2d", occupied) + " araç                  │");
        System.out.println("  │  ✅ Boş             : " + String.format("%-2d", available) + " araç                  │");
        System.out.println("  │                                                │");
        System.out.println("  └────────────────────────────────────────────────┘");
    }

    private static void clearScreen() {
        for (int i = 0; i < 50; i++) System.out.println();
    }

    private static void pressEnterToContinue() {
        System.out.println("\nDevam etmek için ENTER'a basın...");
        scanner.nextLine();
    }

    private static int getIntInput(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            scanner.next();
            System.out.print("Geçerli bir sayı girin: ");
        }
        int value = scanner.nextInt();
        scanner.nextLine();
        return value;
    }

    private static double getDoubleInput(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextDouble()) {
            scanner.next();
            System.out.print("Geçerli bir sayı girin: ");
        }
        double value = scanner.nextDouble();
        scanner.nextLine();
        return value;
    }

    private static String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
}